#ifndef LOSE_H
#define LOSE_H

void innitLose();
void updateLose();
void drawLose();

#endif
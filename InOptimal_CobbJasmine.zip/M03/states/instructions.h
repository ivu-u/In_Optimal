#ifndef INSTRUCTIONS_H
#define INSTRUCTIONS_H

void initIntructions();
void updateInstructions();
void drawInstructions();

#endif
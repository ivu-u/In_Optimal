#ifndef PAUSE_H
#define PAUSE_H

void innitPause();
void updatePause();
void drawPause();

#endif
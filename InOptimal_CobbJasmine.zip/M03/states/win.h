#ifndef WIN_H
#define WIN_H

void innitWin();
void updateWin();
void drawWin();

#endif
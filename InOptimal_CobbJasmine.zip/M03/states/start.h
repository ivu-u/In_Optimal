#ifndef START
#define START

// prototypes
void initStart();
void updateStart();

#endif
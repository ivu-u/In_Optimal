#ifndef CUTSCENE_H
#define CUTSCENE_H

void initCutscene();
void updateCutscene();

#endif
#ifndef PATHWAY_H
#define PATHWAY_H

#define PATHWAY_WIDTH  (32)
#define PATHWAY_HEIGHT (32)
#define pathwayLen (2048)

extern const unsigned short pathwayMap[1024];

#endif

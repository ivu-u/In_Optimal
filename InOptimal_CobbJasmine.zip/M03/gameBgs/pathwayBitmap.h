
//{{BLOCK(pathwayBitmap)

//======================================================================
//
//	pathwayBitmap, 256x256@8, 
//	+ bitmap not compressed
//	Total size: 65536 = 65536
//
//	Time-stamp: 2024-11-17, 00:17:01
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PATHWAYBITMAP_H
#define GRIT_PATHWAYBITMAP_H

#define pathwayBitmapBitmapLen 65536
extern const unsigned short pathwayBitmapBitmap[32768];

#endif // GRIT_PATHWAYBITMAP_H

//}}BLOCK(pathwayBitmap)

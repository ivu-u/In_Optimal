#ifndef LEVEL3_H
#define LEVEL3_H

void init_lvl3_room1();
void draw_lvl3_room1();

#endif
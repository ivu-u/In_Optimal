#include "spider.h"

void initSpiders() {

}

void setSpiderPos(int x, int y) {
    
}
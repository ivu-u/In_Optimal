
# CONTROLS

- UI navigation = Start Button
- Movement = Arrow Keys
- Attack = A Button

# How to Play

- sooo right now you can only lose. Everything is very jank <__< so that's def my bad
- a lot of setup still happening with scalability
- lots of things very broken.... but the major systems are mostly in: Levels manager, Enemy manager, player setup, state machine, bg scroll.
#ifndef CAMERA_H
#define CAMERA_H

void initCamera();
void updateCamera();

#endif
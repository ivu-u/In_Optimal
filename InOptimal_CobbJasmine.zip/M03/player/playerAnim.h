#ifndef PLAYERANIM_H
#define PLAYERANIM_H

void initPlayerAnim();
void drawPlayer();

#endif
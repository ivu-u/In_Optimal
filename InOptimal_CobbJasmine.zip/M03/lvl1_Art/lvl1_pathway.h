#ifndef LVL1_PATHWAY_H
#define LVL1_PATHWAY_H

#define LVL1_PATHWAY_WIDTH  (32)
#define LVL1_PATHWAY_HEIGHT (32)
#define lvl1_pathwayLen (2048)

extern const unsigned short lvl1_pathwayMap[1024];

#endif

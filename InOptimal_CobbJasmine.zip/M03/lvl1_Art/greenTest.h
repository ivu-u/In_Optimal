#ifndef GREENTEST_H
#define GREENTEST_H

#define GREENTEST_WIDTH  (32)
#define GREENTEST_HEIGHT (32)
#define greenTestLen (2048)

extern const unsigned short greenTestMap[1024];

#endif

#ifndef LVL1_TEMPFINAL__H
#define LVL1_TEMPFINAL__H

#define LVL1_TEMPFINAL__WIDTH  (32)
#define LVL1_TEMPFINAL__HEIGHT (32)
#define lvl1_tempFinal_Len (2048)

extern const unsigned short lvl1_tempFinal_Map[1024];

#endif

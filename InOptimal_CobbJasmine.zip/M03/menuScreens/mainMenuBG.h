
//{{BLOCK(mainMenuBG)

//======================================================================
//
//	mainMenuBG, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 246 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 7872 + 2048 = 10432
//
//	Time-stamp: 2024-11-16, 20:45:52
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MAINMENUBG_H
#define GRIT_MAINMENUBG_H

#define mainMenuBGTilesLen 7872
extern const unsigned short mainMenuBGTiles[3936];

#define mainMenuBGMapLen 2048
extern const unsigned short mainMenuBGMap[1024];

#define mainMenuBGPalLen 512
extern const unsigned short mainMenuBGPal[256];

#endif // GRIT_MAINMENUBG_H

//}}BLOCK(mainMenuBG)

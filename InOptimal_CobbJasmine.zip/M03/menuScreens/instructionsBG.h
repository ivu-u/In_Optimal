#ifndef INSTRUCTIONSBG_H
#define INSTRUCTIONSBG_H

#define INSTRUCTIONSBG_WIDTH  (32)
#define INSTRUCTIONSBG_HEIGHT (32)
#define instructionsBGLen (2048)

extern const unsigned short instructionsBGMap[1024];

#endif

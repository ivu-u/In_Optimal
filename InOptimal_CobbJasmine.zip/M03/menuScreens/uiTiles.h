
//{{BLOCK(uiTiles)

//======================================================================
//
//	uiTiles, 80x8@4, 
//	+ palette 256 entries, not compressed
//	+ 10 tiles not compressed
//	Total size: 512 + 320 = 832
//
//	Time-stamp: 2024-11-06, 19:42:12
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_UITILES_H
#define GRIT_UITILES_H

#define uiTilesTilesLen 320
extern const unsigned short uiTilesTiles[160];

#define uiTilesPalLen 512
extern const unsigned short uiTilesPal[256];

#endif // GRIT_UITILES_H

//}}BLOCK(uiTiles)
